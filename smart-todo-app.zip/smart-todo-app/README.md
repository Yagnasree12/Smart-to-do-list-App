# ✅ Smart To-Do List App (Streamlit)

An enhanced interactive Smart To-Do List built with Streamlit.

### Features:
- Add, check, and delete tasks
- AI-prioritized suggestions
- Pomodoro timer
- Productivity analytics
- Export to CSV
- Dark mode

### How to deploy on Streamlit Cloud:
1. Push this project to GitHub
2. Visit https://streamlit.io/cloud
3. Click “New App”
4. Set repository and main file to `smart_todo_app.py`
5. Click Deploy and enjoy 🎉
